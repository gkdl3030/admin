<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login</title>
</head>
<body>
<form action="loginok.php" method="post">
<div>
아이디<input type="text" name="aid">
</div>
<div>
패스워드<input type="password" name="apwd"><br>
</div>
<div>
<input type="submit" value="로그인">
<input type="reset" value="취소">
</div>
</form>

</body>
</html>